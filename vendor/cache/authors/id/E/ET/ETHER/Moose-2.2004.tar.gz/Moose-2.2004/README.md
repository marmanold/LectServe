[![CPAN version](https://badge.fury.io/pl/Moose.svg)](http://badge.fury.io/pl/Moose)
[![Build Status](https://travis-ci.org/moose/Moose.png?branch=master,stable/2.12)](https://travis-ci.org/moose/Moose)
[![Coverage Status](https://coveralls.io/repos/moose/Moose/badge.png?branch=master)](https://coveralls.io/r/moose/Moose?branch=master)

Moose
=====

Moose is a postmodern object system for Perl 5.

Moose on CPAN: [https://metacpan.org/release/Moose]
