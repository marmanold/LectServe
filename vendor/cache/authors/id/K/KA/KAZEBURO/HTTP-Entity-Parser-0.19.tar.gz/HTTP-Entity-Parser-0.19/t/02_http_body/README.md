This test data are copied from HTTP::Body

