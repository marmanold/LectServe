package App;
use Dancer2 appname => 'OtherApp';
use App::Extra;
1;
